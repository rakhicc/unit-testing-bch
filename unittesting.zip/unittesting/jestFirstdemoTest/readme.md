# Jest project

documentation:https://jestjs.io/

## 1.create a project folder

## 2. create package.json (with npm init or manually)

``shell

> npm init -y

````
or
```shell
> npm init
````

and answer questions

## 3. install jest as dev dependency

```shell
> npm install jest --save-dev
```

this modifies the package.json file by adding devDependencies to it

```json
"devDependencies": {
    "jest": "^27.4.7"
  }
```

## 4.Modify test-script in package.json

```json
"scripts": {
    "test": "jest"
  }
```

## 5. create test folder named `__tests__`

## 6. write tests

## 7. to run tests

```shell
>npm test
```

## 7B. to run only one test file

```shell
>npm test --testFile fileToBeTested.test.js
```
