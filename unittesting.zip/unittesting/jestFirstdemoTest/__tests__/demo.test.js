'use strict';
beforeAll(()=>{
    console.log('Before all','init before all tests');
});
afterAll(()=>{
    console.log('After all','cleaning after all tests');
})
test('This is the first test',()=>{
    console.log('first test');
    expect(2+2).toBe(4);
})

it('this is the second test',()=>{
    console.log('second test');

})

describe('tis is a first group of tests',()=>{
    beforeEach(()=>{
        console.log('beforeEach','run before each test in first group');
    })
    afterEach(()=>{
        console.log('afterEach','run after each test in first group');
    })
    test('first test of first group',()=>{
        console.log('firsttest of first group');
    });
    test('second test of first group',()=>{
        console.log('second test of first group');
    });
});

describe('this is second group',()=>{
    beforeAll(()=>{
        console.log('beforeallIngroup2');

    });
    test('first test of second group',()=>{
        console.log('first test of second group');
    });
    describe('first subgroup of the second group',()=>{
        test('first test of sg1',()=>{
            console.log('first of sg1');
        });
        test('second test of sg1',()=>{
            console.log('second of sg1');
        });
    });
    describe('second subgroup of second group tst',()=>{
        test('first of sg2',()=>{
            console.log('first test of sg2');
        });
    });
});

describe('test concatenating strings',()=>{
    const concat=(partA,partB)=>partA+partB;
    test('first and second results firstsecond',()=>{
        expect(concat('first','second')).toBe('firstsecond');
    });
    
});

describe('this tests for an exception',()=>{
    const testFunction=()=>{
        throw Error('this is an exception');
    }
    test('test if a function throws an exception',()=>{
        expect(()=>testFunction()).toThrow('this is an exception');

    });
});