'use strict';
const expect=require('chai').expect;
const PhoneRegister=require('../phoneRegister');
const phones=require('../phones.json');

describe('testing constructor',function(){
    it('missing parameter exception',function(){
        expect(function(){
            new PhoneRegister()
        }).to.throw('phone data missing');
    });
    it('using the deflt data',function(){
        const phoneRegister=new PhoneRegister(phones);
        expect(phoneRegister.phoneRegister).to.equal(phones);
    })
});

describe('test getTypes',function(){
    it('using default data',function(){
        const phoneRegister=new PhoneRegister(phones);
        expect(phoneRegister.getTypes()).to.deep.equal(['home','work','mobile']);
    })
})