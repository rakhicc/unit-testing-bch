'use strict';
function testAll(dataArray) {
    return function(message,callbackfunction){
        for (let row of dataArray){
            console.log(message);
            callbackfunction(...row);
        }
    }
}


const data=[[1,2,3],
[4,5,6]];

testAll(data)('xyz',(a,b,c)=>console.log(a,b,c)); 
const a=testAll(data);
a('xyz',(a,b,c)=>console.log(a,b,c));

console.log(2/0);//infinity
console.log(0/0);//NaN
console.log(-4/0);//-Infinity
console.log(-4/0)===Number.NEGATIVE_INFINITY;// true;