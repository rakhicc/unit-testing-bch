'use strict'
const { TestWatcher } = require('jest');
const Dice=require('../dice.js');
describe('method and getters defined',()=>{
    const dice = new Dice();
    test('minimumValue defined',()=>{
        expect(dice.minimumValue).toBeDefined();
    });
    test('minimumValue is 1',()=>{
        expect(dice.minimumValue).toBe(1);
    });
    test('maximumValue is defined',()=>{
        expect(dice.maximumValue).toBeDefined();
    });
    test('dots defined',()=>{
        expect(dice.dots).toBeDefined();
    });
    test('rolls defined',()=>{
        expect(dice.roll).toBeDefined();
    });
    test('toString defined',()=>{
        expect(dice.toString).toBeDefined();
    });
});

describe('testing constructor',()=>{

})
describe('create a dice with no upper bound given',()=>{
    const dice=new Dice();
    test('maximumvalueis 6',()=>{
        expect(dice.maximumValue).toBe(6);
    })
    test('minimumvalue is 1',()=>{
        expect(dice.minimumValue).toBe(1);
    })
    test('dots is 0',()=>{
        expect(dice.dots).toBe(0);
    })
});

describe('create a dice with upper bound 12',()=>{
    const dice=new Dice(12);
    test('maximumvalue is 12',()=>{
        expect(dice.maximumValue).toBe(12);
    })
    test('minimumvalue is 1',()=>{
        expect(dice.minimumValue).toBe(1);
    })
    test('dots is 0',()=>{
        expect(dice.dots).toBe(0);
    })
});

describe('create a dice with the given upper bound 2-20',()=>{
    const testcases=new Array(19).fill(2).map((val,ind)=>
    [val+ind]);
    test.each(testcases)('test upper bound %s',upperBound =>{
        const dice=new Dice(upperBound);
        expect(dice.maximumValue).toBe(upperBound);
    })
})

describe('testexceptions',()=>{
    const testvalues=[[
        's','Upper bound must be an integer'
    ],
    [
        2.5,'Upper bound must be an integer'
    ],
    [
        -4,'Upper bound too small'
    ],
    [
        1,'Upper bound too small'
    ],
    [
        0,'Upper bound too small'
    ],
    [
        21,'Upper bound too big'
    ],
    [
        100,'Upper bound too big'
    ]];
    test.each(testvalues)('upperbound %s throws an excpetion %s',(upperBound,expected)=>{
        expect(()=>
            new Dice(upperBound)).toThrow(expected);
        
    })
//Ilkkas code
    // describe('Test exceptions', ()=>{
    //     const testValues=[
    //         ['s', 'Upper bound must be an integer'],
    //         [2.5, 'Upper bound must be an integer'],
    //         [-4, 'Upper bound too small'],
    //         [1, 'Upper bound too small'],
    //         [0, 'Upper bound too small'],
    //         [21, 'Upper bound too big'],
    //         [100, 'Upper bound too big']
    //     ];  

    //     test.each(testValues)('upper bound %s throws an exception %s',(ubound,expected)=>{
    //         expect(()=>{
    //             new Dice(ubound)
    //         }).toThrow(expected);
    //     });

    //     //other version
    //     test.each(testValues)('upper bound %s throws an exception %s', (ubound, expected) => {
    //         expect(() => new Dice(ubound)).toThrow(expected);
    //     });
    // });
});



describe('test method roll',()=>{
    describe('test with default upper bound 6',()=>{
        const dice=new Dice();
        test('test when rolled',()=>{
            dice.roll();
            expect(dice.dots).toBeGreaterThanOrEqual(1);
            expect(dice.dots).toBeLessThanOrEqual(6);
        })
        
    })
    describe('test with upper bound 12',()=>{
        const dice=new Dice(12);
        test('test dice when rolled',()=>{
            dice.roll();
            expect(dice.dots).toBeGreaterThanOrEqual(1);
            expect(dice.dots).toBeLessThanOrEqual(12);
        })
    })
    describe('test with upper bound 2-20 after rolling',()=>{
        const testcases=new Array(19).fill(2).map((val,ind)=>
        [val+ind]);
        test.each(testcases)('test upper bound %s',upperBound=>{
           const dice =new Dice(upperBound);
            dice.roll();
            expect(dice.dots).toBeGreaterThanOrEqual(1);
            expect(dice.dots).toBeLessThanOrEqual(upperBound); 
        })
    })
})