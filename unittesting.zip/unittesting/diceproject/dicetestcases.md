# Dice class test class

## test cases for Constructor

- upper bound is integer

- new Dice(2) creates dice with upper bound 2

- new Dice() creates dice with upper bound 6
  -new dice(12)
  new dice(6)
  new dice(20)
  test with all upper bounds 2...20

check that dot count is set to 0.

- new Dice('s') throw `´Upper bound must be an integer'`
- new Dice(2.5) throw
- new Dice(21) throws `´Upper bound must be an integer'`
  -new Dice(100) `´Upper bound too big'`

-new Dice(-4) throws `´Upper bound too small'`
-new Dice(1) throws `´Upper bound too small'`

upper bound 2:dots 1,2
upper bound 4: dots 1,2,3,4

## test cases for method roll

dice =new Dice(upperBound)
dice.roll()
check if 1<= dot count<=upper bound

dice =new Dice()
dice.roll()
check if 1<= dot count<=6

## test cases for toString()

- roll the dice and then compare the dots to the string returned from toString method
  dice=new Dice();
  dice.roll()
  expect(dice.toString()).toBe(`${ice.dots}`)
- If not rolled yet, then shoul return text `'Not rolled yet''
  dice=new Dice();

expect(dice.toString()).toBe('Not rolled yet')
