# Dice class API

This is a dice class for some kind pf dice games.
Dice holds the number of dots. the number of dots is between 1 and given upper bound(included).
the maximum upperbound is 20.
the minimum upper bound is 2.
if the dice hasn't been rolled the number of dots is 0. after the dice has been rolled, the dot count can't become zero again.

## Operations

### ** constructor(upperbound) **

- Initializes the dice with upper bound that is passed as a parameter
  If no upperbound is given,the default upper bound is 6.
  Initializes dot count to zero.

if upperBound is not an integer, throw an exception
`'upper bound must be an integer'`

if upperbound is not between 2 and 20, an exception is thrown:

- upperBound >20: `'Ùpper bound too big'`
  -upperBound <2:`'Ùpper bound too small'`

  ### Methods

  #### **roll()**

- roll the dice
- when rolled, the dot count become a random number between 1 and upperBound (included)
- returns nothing

#### **toString()**

- return dot count as a string. For example:`'4'`
- if the dice hasn't neen rolled yet, returns a text `'not rolled yet'`

### Getters

#### **dots**

- return the number of dots

#### **minimumValue**

- returns the minimum number of the dots. It should be 1.

#### **maximumValue**

- returns the upper bound of the dots.
