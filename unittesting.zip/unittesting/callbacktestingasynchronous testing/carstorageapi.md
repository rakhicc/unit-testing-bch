## cars.json

```json
[
  {
    "model": "Bored T-model",
    "license": "abc"
  },
  {
    "model": "Nova",
    "license": "xyz"
  },
  {
    "model": "bored-model",
    "license": "abc"
  },
  {
    "model": "XGT",
    "license": "B-1"
  }
]
```

## **search(key,value)**

function returns car matching criteria.if no match empty array.if parameter missing all cars in an array is returned

parameters:
key:`model`or `licence``
value:value to be searched

## example

```js
search(`model`, `Nova`);
```
