'use strict';

const { TestWatcher } = require('jest');
const search=require('../carstoragecallbackLast');

describe('testing callback',()=>{
test('search with license abc',done=>{
    function cb(data){
        try{
            expect(data).toEqual([
                {
                    "model":"Bored T-model",
                    "license":"abc"
                }, 
                {
                    "model":"bored-model",
                    "license":"abc"
                }
            ]);
            done();
        } catch(err){
            done(err);
        }

    }
    search('license','abc',cb);
})
});

describe('testing the missing callback',()=>{
    test('callback missing',()=>{
        expect(()=> search('license','abc')).toThrow('callback function missing');
    })
});

describe('testing callback with testeach',()=>{
    const testValues=[
        ['license','XYZ',[]],
        ['model','Nova',[{
            "model":"Nova",
            "license":"xyz"
        }]],
        ['license','abc',[{
            "model":"Bored T-model",
            "license":"abc"
        }, 
        {
            "model":"bored-model",
            "license":"abc"
        }]]
    ]
    test.each(testValues)('%s, %s', (key,value,expected,done)=>{
        function cb(data){
            try{
                expect(data).toEqual(expected);
                done();
            }
            catch(err){
                done(err);
            }
        } //cb ends here
        search(key,value,cb);
    })
})