'use strict';

const { TestWatcher } = require('jest');
const search =require('../carstoragepromiselast');

describe('testing with key license to resolve',()=>{

    const expected=[{
        "model":"Bored T-model",
        "license":"abc"
    }, 
    {
        "model":"bored-model",
        "license":"abc"
    }];
    test('then',()=>{
        return search('license','abc')
        .then(data=>expect(data).toEqual(expected))
    });
    test('async-await',async()=>{
        const data= await search('license','abc');
        expect(data).toEqual(expected)
    });
    test('resolves',()=>{
        return expect(search('license','abc')).resolves.toEqual(expected);
    });
    test('resolves async',async()=>{
        await expect(search('license','abc')).resolves.toEqual(expected);
    })
})

describe('testing with key license to reject',()=>{
    test('catch',()=>{
        return search().catch(data=>expect(data).toBe('parameter missing'))
    })
    test('async-await',async()=>{
        try{
            await search();
        } catch(error){
            expect(error).toBe('parameter missing');
        }
    });

    test('rejects',()=>{
        return expect(search()).rejects.toBe('parameter missing');
    })
    test('rejects with async await',async()=>{
        await expect(search()).rejects.toBe('parameter missing');
    })
});

describe('testing models',()=>{
    test('search model Nova',()=>{
        return expect(search('model','Nova')).resolves.toEqual([{
            "model":"Nova",
            "license":"xyz"
        }
    ]);
    });
    test('parameter missing',()=>{
        return expect(search('model')).rejects.toBe('parameter missing');
    })
})