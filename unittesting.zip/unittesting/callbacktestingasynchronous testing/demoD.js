'use strict';

const search=require('./carstoragepromise');//replace with promise

//search().then(console.log).catch(console.log);

(async()=>{
    try{
        console.log(await search());
        console.log('one');
        console.log(await search('model','Nova'));
        console.log('two');
        console.log(await search('license','abc'));
        console.log('three');
    } catch(err){
        console.log(err.message);
    }
})();