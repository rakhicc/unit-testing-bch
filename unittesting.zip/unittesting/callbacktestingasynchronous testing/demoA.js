'use strict';
//const search=require('./carstoragefile');
const search=require('./carstoragenotworking');
console.log(search());
console.log('one');
console.log(search('model','Nova'));
console.log('two');
console.log(search('license','abc'));