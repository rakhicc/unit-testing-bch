'use strict';

const search=require('./carstoragecallback');
search(console.log);

console.log('one');

search(console.log,'model','Nova');
console.log('two');
search(console.log,'license','abc');
search(data=>console.log(data),`licence`,`abc`);
console.log(`three`);
search(printdata,`model`,`Nova`);

function printdata(data){
    console.log('###');
    console.log(data);
    console.log('###');
}
