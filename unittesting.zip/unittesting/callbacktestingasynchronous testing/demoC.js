'use strict';
const search=require('./carstoragecallbackLast');

try{
    search('model','Nova',console.log);
search();
}catch(err){
    console.log(err.message);
}

search('license','abc',console.log);