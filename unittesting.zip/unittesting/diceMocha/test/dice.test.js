'use strict';

const expect=require('chai').expect;
const Dice=require('../dice');

describe('methods defined',function(){
    const dice=new Dice();
    it('getter maximumvalue defined',function(){
        expect(dice).to.have.a.property('maximumValue');
    });
    it('method roll defined',function(){
        expect(dice).to.have.a.property('roll');
    })
});

describe('create dice with no upperbound given',function(){
    const dice=new Dice();
    it('maximumvalue is 6',function(){
        expect(dice.maximumValue).to.equal(6);
    })
})
describe('create dice with given upperbouund 2-20',function(){
    const testcases=new Array(19).fill(2).map((value,ind)=>value+ind);

    testcases.forEach(function(uBound){
        it(`upper bound is ${uBound}`,function(){
            const dice=new Dice(uBound);
            expect(dice.maximumValue).to.equal(uBound);
        });
    })
})
describe('create dice with given upperbouund 2-20 version 2',function(){
    function testUpperBound(upperBound){
        const dice=new Dice(upperBound);
        it(`upper bound is ${upperBound}`,function(){
            expect(dice.maximumValue).to.equal(upperBound);
        })

        }
        for(let uBound=2;uBound<=20; uBound++){
            testUpperBound(uBound);
        }
    })

    describe('test roll',function(){
        let dice;
       beforeEach(function(){
            dice=new Dice();
        });
        it('test when rolled',function(){
            dice.roll();
            expect(dice.dots).to.be.within(1,6);
        })
        it('test when not rolled yet',function(){
            expect(dice.dots).to.equal(0);
        });
    });
    describe('test toString',function(){
        let dice;
        beforeEach(function(){
            dice=new Dice();
        })
        it('dice is rolled',function(){
            dice.roll();
            expect(dice.toString()).to.equal(`${dice.dots}`);
        });
        it('dice not rolled yet',function(){
            expect(dice.toString()).to.equal('Not rolled yet');
        })
    })
