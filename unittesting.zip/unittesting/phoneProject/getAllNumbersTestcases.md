# getAllNumbers() Test cases

## **getAllNumbers()**

Returns all phone numbers in an array, each as an object of form:

```json
{ "firstname": "", "lastname": "", "phones": [] }
```

The phone object in phones array is of form:

```json
{ "type": "", "number": "" }
```

If a person does not have a phone (the phone field is an empty array or there is no phones field, then the person is not added to result array.)

If all phones are missing, an empty array [] is returned.

## Test 1:test with default data

before test create register object from PhoneRegister class with default data.

```js
register.getAllNumbers();
```

returns the default json array

## Test2 some phones missing:

before test create register object from PhoneRegister class with

```json
[
  {
    "firstname": "Leila",
    "lastname": "Heikki",
    "phones": [
      {
        "type": "home",
        "number": "12345678"
      },
      {
        "type": "work",
        "number": "87688870"
      },
      {
        "type": "work",
        "number": "05045670"
      }
    ]
  },
  {
    "firstname": "Matt",
    "lastname": "River",
    "phones": []
  }
]
```

returns

```json
[
  {
    "firstname": "Leila",
    "lastname": "Heikki",
    "phones": [
      {
        "type": "home",
        "number": "12345678"
      },
      {
        "type": "work",
        "number": "87688870"
      },
      {
        "type": "work",
        "number": "05045670"
      }
    ]
  }
]
```

## Test 3:test all phones are missing or phones field is missing

test data

```json
[
  {
    "firstname": "Leila",
    "lastname": "Heikki",
    "phones": []
  },
  {
    "firstname": "Matt",
    "lastname": "River"
  }
]
```

returns

```json
[]
```

## Test 4:all persons are missing

before test create PhoneRegister object wih empty array[]
returns

```json
[]
```
