## **getPersonsNumbersByType(firstname,lastname,type)**

Method returns an array of phone numbers of the given `type` belonging to given person with given `firstname`and `lastname`.

If no person with given name is found , an empty array [] is returned.

if no number with given type is found,an empty array [] is returned.
If at least one parameter is missing an exception `missing parameter`.

For example':
Leila Heikki and work

```js
["87688870", "05045670"];
```

if atleast one parameter is missing `'mising parameter'` is thrown
getPersonsNumbersByType("firstname","lastname") exception `'mising parameter'`

if no person found with given names empty array [] is returned

before tests create register class with default data.

### test1:

get from default data
getPersonsNumbersByType("Leila","Heikki","work") returns ["87688870","05045670"]

### test 2 matt,river

getPersonsNumbersByType("Matt","River","mobile") returns ["04123456"]

### test 3: wrong type or name returns an empty array

```js
register.getPersonsNumbersByType("Matt", "River", "x");
register.getPersonsNumbersByType("Matt", "x", "River");

register.getPersonsNumbersByType("x", "Matt", "River");
```

returns

```json
[]
```

### test 4:wrong type or name returns an empty array

```js
register.getPersonnumbersbyType("x", "River", "home");
```

## Test 5:missing parameter throws an exception

```js
register.getPersonnumbersbyType("Matt", "River");
```
