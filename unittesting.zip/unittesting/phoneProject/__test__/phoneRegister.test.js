'use strict';

const PhoneRegister = require('../phoneRegister');

const phones=require('../phones.json');

describe('Testing constructor',()=>{
    test('Test 1: object created with given data',()=>{
        const register=new PhoneRegister(phones);
        expect(register.phoneRegister).toEqual(phones);
    })
    test('Test 2:missing parameter throws an exception',()=>{
        expect(()=> new PhoneRegister()).toThrow('phone data missing');
    });
})

describe('testing get types',()=>{
    const testData=[
        {
          "firstname": "Leila",
          "lastname": "Heikki",
          "phones": [
            {
              "type": "work",
              "number": "87688870"
            }
          ]
        }
      ];
    test('Test 1: use default data ',()=>{
        const register=new PhoneRegister(phones);
        expect(register.getTypes()).toEqual(["home", "work", "mobile"]);
    })
    test('Test 2: use custom data ',()=>{
        const register=new PhoneRegister(testData);
        expect(register.getTypes()).toEqual(["work"]);
    })
    test('Test 3: no persons in data ',()=>{
        const register=new PhoneRegister([]);
        expect(register.getTypes()).toEqual([]);
    })
    describe('persons have no phones',()=>{
        test('Test 4: no phones field present ',()=>{
            const testData=[
                {
                  "firstname": "Leila",
                  "lastname": "Heikki"
                },
                {
                  "firstname": "Matt",
                  "lastname": "River"
                }
              ];
            const register=new PhoneRegister(testData);
            expect(register.getTypes()).toEqual([]);
        }) 
        test('Test 5: phone array is empty ',()=>{
            const testData=[
                {
                  "firstname": "Leila",
                  "lastname": "Heikki",
                  "phones": []
                },
                {
                  "firstname": "Matt",
                  "lastname": "River",
                  "phones": []
                }
              ]
            const register=new PhoneRegister(testData);
            expect(register.getTypes()).toEqual([]);
        });  
    });
    test('Test 6: phone object has no type ',()=>{
        const testData=[
            {
              "firstname": "Leila",
              "lastname": "Heikki",
              "phones": [
                {
                  "type": "home",
                  "number": "12345678"
                },
          
                {
                  "number": "05045670"
                }
              ]
            }
          ]
        const register=new PhoneRegister(testData);
        expect(register.getTypes()).toEqual(["home"]);
   
});
});
describe('testing method getTypes test.each.version',()=>{
    const testData=require('../testtypecases.json');
    test('test6 version2 ',()=>{
        const register=new PhoneRegister(testData.test6);
        expect(register.getTypes()).toEqual(["home"]); 
    });
    const testValues=[
        [testData.test2,["work"]],
        [testData.test3,[]],
        [testData.test4,[]]
    ];
    test.each(testValues)('testing..',(a,expected)=>{
        const register=new PhoneRegister(a);
        expect(register.getTypes()).toEqual(expected);

    })
})

describe('test getPersonsNumbersByType',()=>{
  
const register=new PhoneRegister(phones);
    test('test1 default',()=>{
        
    expect(register.getPersonsNumbersByType("Leila","Heikki","work")).toEqual(["87688870",  "05045670"]);
    })
    test('test2 default matt river',()=>{
        
      
      expect(register.getPersonsNumbersByType("Matt","River","mobile")).toEqual(["04123456"]);
      })
      test('test3 wrong type or name returns an empty array',()=>{
        
        expect(register.getPersonsNumbersByType("Matt", "River", "x")).toEqual([]);
      })
      test('test3 wrong type or name returns an empty array',()=>{
        
        expect(register.getPersonsNumbersByType("Matt","x", "River")).toEqual([]);
      })
      test('test3 wrong type or name returns an empty array',()=>{
        
        expect(register.getPersonsNumbersByType("x","Matt","River")).toEqual([]);
      })
      test('Test 5:missing parameter throws an exception ',()=>{
        
        expect(()=> register.getPersonsNumbersByType("Matt","River")).toThrow('missing parameter');
      })
    
    //Using array

    const testvalues=[
      //fistnname,lastname,type,expected test2 to 4
      ["Leila","Heikki","work",["87688870", "05045670"]],
      ["Matt","River","mobile",["04123456"]],
      ["Matt","River","x",[]],
      ["Matt","x","River",[]],
      ["x","River","mobile",[]],
      ["x","y","z",[]]
    ];
    test.each(testvalues)('getPersonsNumbersByType("%s","%s","%s") returns "%s"',(firstname,lastname,type,expected)=>{
      expect(register.getPersonsNumbersByType(firstname,lastname,type)).toEqual(expected);
    })
      
  describe('test5:missing parameter throws an exception',()=>{
    test('one parameter missing',()=>{
      expect(()=>register.getPersonsNumbersByType("Matt","River")).toThrow("missing parameter");
    })
    test('two parameter missing',()=>{
      expect(()=>register.getPersonsNumbersByType("Matt")).toThrow("missing parameter");
    })
    test('all parameters missing',()=>{
      expect(()=>register.getPersonsNumbersByType()).toThrow("missing parameter");
    })
  })
  
 
  
  describe('getAllNumbersByType(type)',()=>{ 
const register=new PhoneRegister(phones);
const testOneWorkExpected=[
  {
    "firstname": "Leila",
    "lastname": "Heikki",
    "number": { "type": "work", "tel": "87688870" }
  },
  {
    "firstname": "Leila",
    "lastname": "Heikki",
    "number": { "type": "work", "tel": "05045670" }
  },
  {
    "firstname": "Matt",
    "lastname": "River",
    "number": { "type": "work", "tel": "32145678" }
  }
]
const testOneMobileExpected=[

  {
      "firstname":"Matt",
      "lastname":"River",
      "number":
          {

      
          "type":"mobile",
          "tel":"04123456"
                  }
  
  }
]
const testOneHomeExpected=[
  {
      "firstname":"Leila",
      "lastname":"Heikki",
      "number":
          {
"type":"home",
"tel":"12345678"
      }
  
  },
  {
      "firstname":"Matt",
      "lastname":"River",
      "number":
          {
"type":"home",
"tel":"56789012"
      }
      
  }
]
const testvalues=[
  //fistnname,lastname,type,expected test2 to 4
  ["work",testOneWorkExpected],
  ["mobile",testOneMobileExpected],
  ["home",testOneHomeExpected],
  ["x",[]]
];
test.each(testvalues)('getAllNumbersByType("%s") returns "%s',(type,expected)=>{
  expect(register.getAllNumbersByType(type)).toEqual(expected);
})

//testing individually

test('getAllNumbersByType(home)',()=>{
  expect(register.getAllNumbersByType('home')).toEqual(testOneHomeExpected);
})

test('getAllNumbersByType(mobile)',()=>{
  expect(register.getAllNumbersByType('mobile')).toEqual(testOneMobileExpected);
})
test('getAllNumbersByType(work)',()=>{
  expect(register.getAllNumbersByType('work')).toEqual(testOneWorkExpected);
})
describe('test3 no parameter',()=>{
test('getAllNumbersByType() without parameter',()=>{
  expect(()=>register.getAllNumbersByType()).toThrow('missing parameter');
})
})
describe('test2 wrong parameter',()=>{
test('getAllNumbersByType(x) with wrong parameter',()=>{
  expect(register.getAllNumbersByType('x')).toEqual([]);
})
})

 })
})
 describe('test getAllNumbersTestcases',()=>{
   test('test1 test with default data',()=>{
     const register=new PhoneRegister(phones);
     expect(register.getAllNumbers()).toEqual(phones);
   })
   test('Test2 some phones missing',()=>{
     const test2Data=[
      {
        "firstname": "Leila",
        "lastname": "Heikki",
        "phones": [
          {
            "type": "home",
            "number": "12345678"
          },
          {
            "type": "work",
            "number": "87688870"
          },
          {
            "type": "work",
            "number": "05045670"
          }
        ]
      },
      {
        "firstname": "Matt",
        "lastname": "River",
        "phones": []
      }
    ]
    const testTwoResult=[
      {
        "firstname": "Leila",
        "lastname": "Heikki",
        "phones": [
          {
            "type": "home",
            "number": "12345678"
          },
          {
            "type": "work",
            "number": "87688870"
          },
          {
            "type": "work",
            "number": "05045670"
          }
        ]
      }
    ]
    const register=new PhoneRegister(test2Data);
    expect(register.getAllNumbers()).toEqual(testTwoResult);
  })
  test('test 3 test all phones are missing or phones field is missing',()=>{
    const testData=[
      {
        "firstname": "Leila",
        "lastname": "Heikki",
        "phones": []
      },
      {
        "firstname": "Matt",
        "lastname": "River"
      }
    ]
    
    const register=new PhoneRegister(testData);
    expect(register.getAllNumbers()).toEqual([]);
  })

  test('Test 4:all persons are missing',()=>{
    const register=new PhoneRegister([]);
    expect(register.getAllNumbers()).toEqual([]);
  })
 })

 describe('test getName(number)',()=>{
  const register=new PhoneRegister(phones);
test('test1 get name who has number 05045670',()=>{
  const testResult1={
    "firstname":"Leila",
    "lastname":"Heikki"}
  
  expect(register.getName("05045670")).toEqual(testResult1);
})
describe('test2 get names by number from default data',()=>{
  const testValues = [
    [
      "12345678",
      {
        firstname: "Leila",
        lastname: "Heikki",
      },
    ],
    ["56789012", { firstname: "Matt", lastname: "River" }],
    ["04123456", { firstname: "Matt", lastname: "River" }],
  ];
  test.each(testValues)('testing with default data.. getName("%s") results "%s"',(number,expected)=>{
    expect(register.getName(number)).toEqual(expected);
  })
})

test('test3 no phone with given number found',()=>{
  
  expect(register.getName("05045688")).toBeNull();
})
test('test4 no phone with given number found',()=>{

  expect(register.getName()).toBeNull();
})
 })


