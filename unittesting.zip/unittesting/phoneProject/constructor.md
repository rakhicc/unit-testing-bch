# Test cases

## **constructor(data)**

Phones json array is passed as a parameter `data`.
If the parameter is missing,this constructr throws exception `'phone data missing'`.

### Test 1: object created with given data

```js
new PhoneRegister(jsonData);
```

test if the inner field of the created objects inner field has the same value as given as parameter. parameter `jsonData` is the json array from the default file `phones.json`

### Test 2:missing parameter throws an exception

```js
new PhoneRegister();
```

this will throw an exception `´phone data missing'`

If we change the fieldname described(fixed) in the aPI, then it okay to test also.
