## **getName(number)**

The method searches the given phone number from the telephone registry , if the number found the method returns a json object
of form

```json
{ "firstname": "", "lastname": "" }
```

If no phone with given number found the method returns `null`.
If the parameter is missing `null`is also returned.

before test ceate phoneregister object from class with default data

### Test 1 get name who has number "05045670"

```js
register.getName("05045670")*;
```

The returned value will be:

```json
{
  "firstname": "Leila",
  "lastname": "Heikki"
}
```

### test2 get names by number from default

```js
const testValues = [
  [
    "12345678",
    {
      firstname: "Leila",
      lastname: "Heikki",
    },
  ],
  ["56789012", { firstname: "Matt", lastname: "River" }],
  ["04123456", { firstname: "Matt", lastname: "River" }],
];
```

### Test3 wrong number

call

```js
register.getname("0000");
```

returns null

### test 4 parameter missing

call

```js
register.getname();
```

returns null
