## **getTypes()**

returns all phone types in an array. The type is added to result array only once.
If there are no phones or no persons an empty array is returned.
For example:

```json
["home", "work", "mobile"]
```

Before test create phoneRegister object from the class PhoneRegister

### Test 1: use default data

get types of the default data

returns

```json
["home", "work", "mobile"]
```

### Test 2 with custom data

get types of the given data where exists only one type of phones.

#### test data

```json
[
  {
    "firstname": "Leila",
    "lastname": "Heikki",
    "phones": [
      {
        "type": "work",
        "number": "87688870"
      }
    ]
  }
]
```

returns

```json
[work]
```

### Test 3:no persons in phone register

#### test data

```json
[]
```

returns

```json
[]
```

### Test 4: persons have no phones

#### test data

```json
[
  {
    "firstname": "Leila",
    "lastname": "Heikki"
  },
  {
    "firstname": "Matt",
    "lastname": "River"
  }
]
```

returns

```json
[]
```

### Test 5: phone array is empty

persons have no phones-phone array is empty

#### test data

phone array is empty

```json
[
  {
    "firstname": "Leila",
    "lastname": "Heikki",
    "phones": []
  },
  {
    "firstname": "Matt",
    "lastname": "River",
    "phones": []
  }
]
```

returns

```json
[]
```

### Test 6: phone object has no type

#### test data

```json
[
  {
    "firstname": "Leila",
    "lastname": "Heikki",
    "phones": [
      {
        "type": "home",
        "number": "12345678"
      },

      {
        "number": "05045670"
      }
    ]
  }
]
```

returns

```json
[home,undefined]
```

```json
[
  {
    "firstname": "Leila",
    "lastname": "Heikki",
    "phones": [
      {
        "type": "home",
        "number": "12345678"
      },

      { "type": "", "number": "05045670" }
    ]
  }
]
```

returns

```json
[home,""]
```
