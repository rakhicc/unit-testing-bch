# Testcases

## **getAllNumbersByType(type)**

Returns an array of objects consisting of names and numbers of given types.
If no number of given type is found , returns an empty aray [].

If a person have multiple numbers of the same type, each of them will be in it's own object.

If a parameter `type`is missing , an exception `missing prameter is thrown.

The format of the returned array of object is :

```json
[
    {
        "firstname":""
,
"lastname":"",
"number" :{"type":"","tel":""}
    },
{
        "firstname":""
,
"lastname",
"number" :{"type":"","tel":""}
}
]
```

### Example type work:

### Test1 :getAllnumbersByType(work) mobile ad home

returns:

```json
[
  {
    "firstname": "Leila",
    "lastname": "Heikki",
    "number": { "type": "work", "tel": "87656789" }
  },
  {
    "firstname": "Leila",
    "lastname": "Heikki",
    "number": { "type": "work", "tel": "56786789" }
  },
  {
    "firstname": "Matt",
    "lastname": "River",
    "number": { "type": "work", "tel": "87656789" }
  }
]
```

by mobile returns only one item

```json
[

    {
        "firstname":"Matt",
        "lastname":"River",
        "phones":[
            {

        {
            "type":"mobile",
            "number":"04123456"
                    }
    ]
    }
]
```

by home returns

````json
[
    {
        "firstname":"Leila",
        "lastname":"Heikki",
        "phones":[
            {
"type":"home",
"number":"12345678"
        }
    ]
    },
    {
        "firstname":"Matt",
        "lastname":"River",
        "phones":[
            {
"type":"home",
"number":"56789012"
        }
        ]
    }
]
```
### Test 2:if type is missing throws an exception

```js
register.getAllNumbersByType();
````

throws an exception `missing parameter`

### Test 3:if type does not exists returns an empty array

```js
register.getAllNumbersByType("x");
```

returns []
